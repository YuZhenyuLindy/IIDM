# GENERATED VERSION FILE
# TIME: Thu Jun 29 17:48:14 2023
__version__ = '1.4.0'
__gitsha__ = 'f6e21db'
version_info = (1, 4, 0)
